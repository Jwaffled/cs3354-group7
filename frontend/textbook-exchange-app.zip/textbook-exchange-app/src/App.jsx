import { Routes, Route, Link } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes';

function App() {
    return <AppRoutes />;
}

export default App;
